package SaucetestNG;

import org.testng.annotations.Test;

import Pages.Model_Page;
import Pages.TEchical;
import Pages.getdata;
import utilities.Library;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class BWMTESTNG extends Library {
	WebDriver dr;
  
  @BeforeClass
  public void beforeClass() {
	  dr=Launch_browser("CHROME","https://www.bmw.in/en/");
  }
  @Test
  public void f() throws InterruptedException {
	  Model_Page M=new Model_Page(dr);
	  M.total_m();
  }
  @Test
  public void f1() throws InterruptedException {
	  TEchical M=new TEchical(dr);
	  M.techi();
  }
  @Test
  public void f2() throws InterruptedException{
	  getdata M2=new getdata(dr);
	  int n=M2.HPValue();
	  writeexcel(n);
	  boolean b=true;
	  if(n<500)
	  {
		  b=false;
		  Assert.assertTrue(b,"dont met requirement");
	  }
	  else
	  {
		  Assert.assertTrue(b," met requirement");
	  }
	  
	  System.out.println(n);
  }


}
