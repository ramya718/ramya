
public class substring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="195 (265) / 4,000";
		int s1=s.indexOf("(");
		String s2=s.substring(5, 8);
		System.out.println(s2);

	}

}
