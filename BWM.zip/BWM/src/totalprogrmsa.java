import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class totalprogrmsa {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//        //a[@href='/alaska-whale-watching-and-wildlife']  --> watching link //a[@href='/cruise-ships']
		// //img[@title='Rhapsody of the Seas, Aerial View With Sunset, Canary Islands, Greece, and Croatia Destinations']
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		 WebDriver dr=new ChromeDriver();
		 dr.get("https://www.royalcaribbean.com/alaska-cruises");
		String s= dr.findElement(By.xpath(" //a[@href='/alaska-whale-watching-and-wildlife']")).getText();
		System.out.println(s);
		boolean b=dr.findElement(By.xpath(" //a[@href='/alaska-whale-watching-and-wildlife']")).isDisplayed();
		System.out.println(b);
		dr.findElement(By.xpath("//a[@href='/cruise-ships']")).click();
		
		Thread.sleep(2000);
		dr.findElement(By.xpath("//figure[@class='header__buttonIcon']//following::img[5]")).click();
		// //input[@class='headerSearchBox__input'][1]
		Thread.sleep(2000);
		dr.findElement(By.xpath("//input[@class='headerSearchBox__input'][1]")).sendKeys("Rhapsody of the Seas");
		//   //div[@class='headerSearchBox__icon'][1]
		Thread.sleep(2000);
		dr.findElement(By.xpath(" //div[@class='headerSearchBox__icon'][1]")).click();
		//  //div[@class='searchResult__title']//child::a[1]
		Thread.sleep(2000);
		dr.findElement(By.xpath("//div[@class='searchResult__title']//child::a[1]")).click();
		//   //div[@class='filterDestination__base'][3]
		Thread.sleep(2000);
		dr.findElement(By.xpath("//div[@class='filterDestination__base'][3]")).click();


	}

}
