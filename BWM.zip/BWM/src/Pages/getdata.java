package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilities.Library;

public class getdata extends Library {
WebDriver dr;
	
	
	By Lnk=By.xpath("//*[@id=\\\"top-of-content\\\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[1]/div/table/tbody/tr[4]/td[2]/div");
	public getdata(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public int HPValue()
	{
		String s=dr.findElement(By.xpath("//*[@id=\"top-of-content\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[1]/div/table/tbody/tr[4]/td[2]/div")).getText();
		System.out.println(s);
		String s2=s.substring(5, 8);
		System.out.println(s2);
		int n=Integer.parseInt(s2);
		System.out.println(n);
		
		return n;
	}
}
