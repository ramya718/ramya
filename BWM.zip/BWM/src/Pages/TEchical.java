package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilities.Library;

public class TEchical extends Library{
	WebDriver dr;
	
	
	By Lnk=By.xpath("//div[@class='scroll-navigation-content tw-h-full']//following::a[2]");
	public TEchical(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void techi()
	{
		WebElement  we1=WaitForClickable(Lnk,20);
		we1.click();
	}

}
