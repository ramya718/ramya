package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.Library;

public class Model_Page extends Library {
	
	By Lnk=By.xpath("//div[@class='tw-cursor-pointer'][1]//child::a");
	By Lnk1=By.xpath("//div[@size='MD'][1]//following::div[@size='MD'][1]//following::a[4]");
	WebDriver dr;
	
	public Model_Page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void model() {
		
		WebElement  we=WaitForClickable(Lnk,20);
		we.click();
		
		
	}
	
	public void seven_series()
	{
		WebElement  we1=WaitForClickable(Lnk1,20);
		we1.click();
	}
	
	public void fin_outmore() throws InterruptedException
	{
		WebDriverWait wt1=new WebDriverWait(dr,20);    
		WebElement we1= wt1.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='lg:tw-w-1/4 sm:tw-w-1/2 tw-w-full tw-relative']//child::img")));
		Actions A=new Actions(dr);
		A.moveToElement(we1).build().perform();
		Thread.sleep(2000);
		dr.findElement(By.xpath("//div[@class='lg:tw-w-1/4 sm:tw-w-1/2 tw-w-full tw-relative']//child::a[@aria-label='Find out more']")).click();
	}
	
	
	public void total_m() throws InterruptedException
	{
		this.model();
		this.seven_series();
		this.fin_outmore();
	}
	
	

}
