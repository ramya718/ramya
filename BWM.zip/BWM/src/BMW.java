


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BMW {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");   ///span[@for='Email']
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.bmw.in/en/");	
		dr.manage().window().maximize();   //            //div[@class='tw-cursor-pointer'][1]//child::a
		
		dr.findElement(By.xpath("//div[@class='tw-cursor-pointer'][1]//child::a")).click();
		Thread.sleep(2000);
		
		WebDriverWait wt=new WebDriverWait(dr,20);         //   import org.openqa.selenium.support.ui.ExpectedConditions;
		WebElement we= wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@size='MD'][1]//following::div[@size='MD'][1]//following::a[4]")));  //import org.openqa.selenium.support.ui.WebDriverWait;
		we.click();
		
		//  //div[@size='MD'][1]//following::div[@size='MD'][1]//following::img[1]
		
		
		////*[@id="top-of-content"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[1]/div/table/tbody/tr[4]/td[2]/div
//		
	
		WebDriverWait wt1=new WebDriverWait(dr,20);    
		WebElement we1= wt1.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='lg:tw-w-1/4 sm:tw-w-1/2 tw-w-full tw-relative']//child::img")));
		Actions A=new Actions(dr);
		A.moveToElement(we1).build().perform();
		Thread.sleep(2000);
		dr.findElement(By.xpath("//div[@class='lg:tw-w-1/4 sm:tw-w-1/2 tw-w-full tw-relative']//child::a[@aria-label='Find out more']")).click();
		
		
		dr.findElement(By.xpath("//div[@class='scroll-navigation-content tw-h-full']//following::a[2]")).click();
		
		String s=dr.findElement(By.xpath("//*[@id=\"top-of-content\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[1]/div/table/tbody/tr[4]/td[2]/div")).getText();
        System.out.println(s);
        String s2=s.substring(5, 8);
		System.out.println(s2);
		
	}

}