package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page_2{
		
		WebDriver dr;
		public Page_2(WebDriver dr)
		{
			this.dr = dr;
		}
	
	public void enter()
	{
	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[1]/input")).sendKeys("rizwana");
	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[2]/input")).sendKeys("123456789");
	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[4]/textarea")).sendKeys("how are you?");
	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[6]/input[3]")).click();
	String last=dr.findElement(By.xpath("/html/body/div[2]/div[1]/div[3]/section/div/div/div/div/div/article/div[3]/form/fieldset/div[1]")).getText();
	System.out.println(last);
	}
}
