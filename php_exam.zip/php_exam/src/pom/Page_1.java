package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page_1 {
	
	WebDriver dr;
	public Page_1(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public void models()
	{
		dr.findElement(By.xpath("//*[@id=\"dropdownCurrency\"]")).click();
		dr.findElement(By.xpath("//*[@id=\"header-waypoint-sticky\"]/div[1]/div/div/div[2]/div/ul/li[1]/div/div/div/a[4]")).click();
		try {
			Thread.sleep(40);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//	String offer=dr.findElement(By.xpath("/html/body/div[2]/div[1]/div[3]/section/div/div[1]/h2")).getText();
//	System.out.println(offer);
	//upto offers
	
	try {
		Thread.sleep(20);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//div[@class='content-bottom mt-auto']//following::a")).click();
//	String vacation=dr.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/section/div/div/div[2]/div/div/div[7]/div/div[2]/div/div[1]/div/div[1]/h5/a")).getText();
//	System.out.println(vacation);
	
	
	try {
		Thread.sleep(30);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/section/div/div/div[2]/div/div/div[7]/div/div[2]/div/div[3]/div/div/a")).click();
	
//	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[1]/input")).sendKeys("rizwana");
//	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[2]/input")).sendKeys("123456789");
//	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[4]/textarea")).sendKeys("how are you?");
//	dr.findElement(By.xpath("//*[@id=\"OVERVIEW\"]/section/div/div/div/div/div/article/div[3]/form/fieldset/div/div[6]/input[3]")).click();
//	String last=dr.findElement(By.xpath("/html/body/div[2]/div[1]/div[3]/section/div/div/div/div/div/article/div[3]/form/fieldset/div[1]")).getText();
//	System.out.println(last);
//	
	
	
	
	
	
	
	}
	
	
	

}