package base_util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {
	
	WebDriver dr;
	public Utilities()
	{
		this.dr = dr;
	}
	
	public WebDriver launch_browser(String browser, String url)
	{
		if(browser.contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr = new ChromeDriver();
		}
		else if(browser.contains("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr = new FirefoxDriver();
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
	


}
