package testng;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base_util.Utilities;
import pom.Page_1;
import pom.Page_2;

public class TestNG_Chrome {

	WebDriver dr;
	Utilities util;
	Page_1 p1;
	Page_2 p2;
	String url ="https://www.phptravels.net/home";
	
	@BeforeClass
	public void browser_type()
	{
		util = new Utilities();
		dr = util.launch_browser("chrome", url);
	}
	
  @Test
  public void f1() 
  {
	  p1=new Page_1(dr);
	  p1.models();
	  p2=new Page_2(dr);
	  p2.enter();
  }
	  
@AfterClass

public void f2()
{
	dr.close();
}
}