package com.cts.test;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.cts.base.LaunchWebDriver;
import com.cts.pages.SeleniumHomePage;

public class SeleniumIEdownloadTest extends LaunchWebDriver {

	@Test
	public void downloadZipTest() throws InterruptedException {

		String downloadPath = System.getProperty("user.dir") + File.separator + "downloads";

		// click on downloads
		SeleniumHomePage.clickOnDownloads(driver);

		// click on 64 bit window IE
		SeleniumHomePage.clickOnWindowsIEDownloads(driver);

		// downloading  time
		Thread.sleep(20000);

		// for getting downloaded file location
		File file = new File(downloadPath + "\\IEDriverServer_x64_3.150.1.zip");

		// Assertion on file downloading
		boolean check = file.exists();
		
		// on check = true when file is downloaded
		// on check = false when file is not download with assert message file "Not  downloaded!!!"
		Assert.assertTrue(check, "Not downloaded!!!");
		System.out.println("windows IE Driver is downloaded ");
	}

}
