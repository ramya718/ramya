package com.cts.base;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class LaunchWebDriver {
	public WebDriver driver;

	@BeforeMethod
	public void setUpBrowser() {

		String downloadPath = System.getProperty("user.dir") + File.separator + "downloads";
		System.out.println(downloadPath);

		// setting download path directory
		Map<String, String> prefs = new HashMap<String, String>();
		prefs.put("download.default_directory", downloadPath);

		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		
		// Launch browser
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");

		// passing options to chromeDriver constructors
		driver = new ChromeDriver(options);

		// maximize browser window
		driver.manage().window().maximize();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// opening the site
		driver.get("https://www.seleniumhq.org");

	}

	@AfterMethod
	public void closeBrowser() {
		// close browser
		driver.quit();
	}
}
