package com.cts.pages;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.cts.base.LaunchWebDriver;

public class SeleniumHomePage extends LaunchWebDriver {

	private static By downloadsLoc = By.xpath("//a[contains(text(),'Downloads')]");
	private static By windowsIELoc = By.xpath("//a[contains(text(),'64 bit Windows IE')]");

	public static void clickOnDownloads(WebDriver driver) {
		driver.findElement(downloadsLoc).click();
	}

	public static void clickOnWindowsIEDownloads(WebDriver driver)

	{
		driver.findElement(windowsIELoc).click();
	}
}
